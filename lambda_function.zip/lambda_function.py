import json
import requests
import boto3

s3cl = boto3.client('s3')

def lambda_handler(event, context):
    api_endpoint = 'https://dtpe7q1kna.execute-api.us-east-1.amazonaws.com/prod/customers'
    
    bucketn = event['Records'][0]['s3']['bucket']['name']
    
    key = event['Records'][0]['s3']['object']['key']
    
    print(bucketn)
    print (key)
    
    response = s3cl.get_object(Bucket=bucketn, Key=key)
    
    data = json.loads(response['Body'].read().decode('utf-8'))
    
    print(data)

    response = requests.post(api_endpoint, json=data)

    if response.status_code == 200:
        
        return {'statusCode': 200, 'body': response.json()}
    else:
        return {'statusCode': response.status_code, 'body': 'Error invoking API'}